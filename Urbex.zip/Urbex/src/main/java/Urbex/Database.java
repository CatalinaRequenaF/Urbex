package Urbex;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

public class Database {
	private static Database instancia;
	private Connection con;
	
	public static Database getInstancia() {
		if(instancia == null) {
			instancia = new Database();
		}
		
		return instancia;
	}
	
	private Database() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://192.168.56.50/urbex";
			Connection con = DriverManager.getConnection(url, "root", "cicle");
			this.con = con;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Map<String,Object>> query(String query) {
        List<Map<String,Object>> list = new ArrayList<Map<String, Object>>();
        
		try {
			PreparedStatement stmt = this.con.prepareStatement(query);
			ResultSet rs = stmt.executeQuery();
	        ResultSetMetaData md = (ResultSetMetaData) rs.getMetaData();
	        int columnCount = md.getColumnCount();
			
	        while (rs.next()) {
	            Map<String,Object> rowData = new HashMap<String,Object>();
	            for(int i = 1;i<=columnCount;i++){
	                rowData.put(md.getColumnName(i), rs.getObject(i));
	            }
	            //System.out.println(rowData);
	            list.add (rowData);
	        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return list;
		
	}
}


