package Urbex;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		Database prueba = Database.getInstancia();
		System.out.println("Connected");
	
		List<Map<String,Object>> resultado = prueba.query("select * from users");
		
		for (int i = 0; i < resultado.size(); i++) {
			System.out.println("Voy a pintar la fila: " + i);
			Map<String,Object> row = resultado.get(i);
			
			for (Map.Entry<String,Object> entrada : row.entrySet()) {
				System.out.println("la clave es: " + entrada.getKey());
				System.out.println("el valor es: " + entrada.getValue());
			}
		}
		
		System.out.println("Fin del programa");
	}

}
